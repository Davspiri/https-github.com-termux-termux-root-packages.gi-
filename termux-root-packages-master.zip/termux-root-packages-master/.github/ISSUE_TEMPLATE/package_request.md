---
name: Package request
about: Suggest a new package

---

<!-- Important note: motivating 'why this package is needed' will most likely give the package higher priority in the developers TODO-list -->

**Package description**
Describe what this package do and why it should be available.

**Link to home page and sources**
1. Home page:
2. Source code:

**Additional information**
Have you compiled or tried to compile the package on device?
* If it didn't work then please provide the error you ran into
* If it did work then please share any patches that you had to apply
