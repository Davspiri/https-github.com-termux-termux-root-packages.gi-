This hsearch(3) implementation is mostly based on the one present in FreeBSD 11.1.
